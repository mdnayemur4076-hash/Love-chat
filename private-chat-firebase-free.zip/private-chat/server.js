const express = require("express");
const session = require("express-session");
const multer = require("multer");
const Database = require("better-sqlite3");
const http = require("http");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { WebSocketServer } = require("ws");

const app = express();
const server = http.createServer(app);
const db = new Database("chat.db");
const MEDIA = path.join(__dirname, "media");
fs.mkdirSync(MEDIA, {recursive:true});

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  text TEXT,
  file_name TEXT,
  file_type TEXT,
  file_path TEXT,
  created_at TEXT NOT NULL
);
`);

const DEFAULT_PASSWORD = process.env.CHAT_PASSWORD || "CHANGE-ME";
const hash = p => crypto.createHash("sha256").update(p).digest("hex");
const count = db.prepare("SELECT COUNT(*) c FROM users").get().c;
if (!count) {
  const add = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)");
  add.run("person1", hash(process.env.PERSON1_PASSWORD || DEFAULT_PASSWORD));
  add.run("person2", hash(process.env.PERSON2_PASSWORD || DEFAULT_PASSWORD));
}

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex"),
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:false, maxAge:1000*60*60*24*30}
}));

function auth(req,res,next) {
  if (!req.session.userId) return res.status(401).json({error:"Not logged in"});
  next();
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_,__,cb)=>cb(null,MEDIA),
    filename: (_,file,cb)=>cb(null,Date.now()+"-"+crypto.randomBytes(8).toString("hex")+path.extname(file.originalname))
  }),
  limits:{fileSize: 100*1024*1024},
  fileFilter: (_,file,cb)=>{
    if (/^(image|video)\//.test(file.mimetype)) cb(null,true);
    else cb(new Error("Only images and videos are allowed"));
  }
});

app.post("/api/login",(req,res)=>{
  const u=db.prepare("SELECT * FROM users WHERE username=? AND password_hash=?")
    .get(req.body.username,hash(req.body.password||""));
  if(!u) return res.status(401).json({error:"Wrong username or password"});
  req.session.userId=u.id;
  req.session.username=u.username;
  res.json({username:u.username});
});

app.post("/api/logout",auth,(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({username:req.session.username||null}));

app.get("/api/messages",auth,(req,res)=>{
  const rows=db.prepare(`
    SELECT m.id,m.text,m.file_name,m.file_type,m.file_path,m.created_at,u.username
    FROM messages m JOIN users u ON u.id=m.user_id
    ORDER BY m.id ASC LIMIT 500`).all();
  res.json(rows);
});

app.post("/api/messages",auth,upload.single("file"),(req,res)=>{
  const file=req.file;
  const info=db.prepare(`
    INSERT INTO messages(user_id,text,file_name,file_type,file_path,created_at)
    VALUES(?,?,?,?,?,datetime('now'))`)
    .run(req.session.userId,req.body.text||null,file?.originalname||null,
         file?.mimetype||null,file?"/media/"+file.filename:null);
  const msg=db.prepare(`
    SELECT m.id,m.text,m.file_name,m.file_type,m.file_path,m.created_at,u.username
    FROM messages m JOIN users u ON u.id=m.user_id WHERE m.id=?`).get(info.lastInsertRowid);
  broadcast(JSON.stringify({type:"message",message:msg}));
  res.json(msg);
});

app.use("/media",auth,express.static(MEDIA));
app.use(express.static(path.join(__dirname,"public")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

const wss=new WebSocketServer({server});
function broadcast(data){ for(const c of wss.clients) if(c.readyState===1) c.send(data); }
wss.on("connection",(ws,req)=>{
  // WebSocket is only used for notifications; normal API requests remain session-protected.
  ws.send(JSON.stringify({type:"connected"}));
});

const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log("Private chat running on port "+PORT));
