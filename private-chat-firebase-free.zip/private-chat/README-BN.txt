# 2-Person Private Chat (Firebase-free)

এটি একটি ছোট private chat starter: Node.js + Express + SQLite + WebSocket।
Text, image এবং video message support করে।

## চালানোর জন্য
1. Node.js 20+ ইনস্টল করুন।
2. এই folder-এ terminal খুলুন।
3. `npm install`
4. Linux/macOS:
   `CHAT_PASSWORD="একটি শক্ত পাসওয়ার্ড" SESSION_SECRET="লম্বা-র‍্যান্ডম-সিক্রেট" npm start`
   Windows PowerShell:
   `$env:CHAT_PASSWORD="একটি শক্ত পাসওয়ার্ড"; $env:SESSION_SECRET="লম্বা-র‍্যান্ডম-সিক্রেট"; npm start`
5. Browser-এ `http://localhost:3000`

ডিফল্ট দুই username: `person1` এবং `person2`.
যদি PERSON1_PASSWORD/PERSON2_PASSWORD না দেওয়া হয়, দুজনের জন্য CHAT_PASSWORD ব্যবহৃত হবে।

## গুরুত্বপূর্ণ
ইন্টারনেটে প্রকাশ করতে একটি Node.js hosting/VPS লাগবে এবং HTTPS ব্যবহার করা উচিত।
ভিডিওর সর্বোচ্চ upload size বর্তমানে 100 MB।
