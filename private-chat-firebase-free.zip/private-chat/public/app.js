let me=null;
const $=id=>document.getElementById(id);
async function login(){
  const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({username:$("user").value,password:$("pass").value})});
  const d=await r.json(); if(!r.ok){$("err").textContent=d.error;return}
  me=d.username;$("login").classList.add("hidden");$("app").classList.remove("hidden");load();
  connect();
}
async function load(){
  const r=await fetch("/api/messages"); if(!r.ok)return;
  const rows=await r.json(); $("messages").innerHTML=""; rows.forEach(add);
  $("messages").scrollTop=$("messages").scrollHeight;
}
function add(m){
  const d=document.createElement("div");d.className="msg "+(m.username===me?"me":"");
  let html=`<div class="name">${esc(m.username)}</div>`;
  if(m.text) html+=`<div>${esc(m.text)}</div>`;
  if(m.file_path){
    if(m.file_type.startsWith("image/")) html+=`<img src="${m.file_path}">`;
    else if(m.file_type.startsWith("video/")) html+=`<video src="${m.file_path}" controls></video>`;
  }
  html+=`<div class="time">${new Date(m.created_at.replace(" ","T")+"Z").toLocaleString()}</div>`;
  d.innerHTML=html;$("messages").appendChild(d);$("messages").scrollTop=$("messages").scrollHeight;
}
$("send").onsubmit=async e=>{
  e.preventDefault(); const f=$("file").files[0],t=$("text").value.trim();
  if(!t&&!f)return; const fd=new FormData(); if(t)fd.append("text",t);if(f)fd.append("file",f);
  const r=await fetch("/api/messages",{method:"POST",body:fd}); if(r.ok){$("text").value="";$("file").value="";$("preview").textContent="";}
};
$("file").onchange=()=>{$("preview").textContent=$("file").files[0]?.name||""};
async function logout(){await fetch("/api/logout",{method:"POST"});location.reload()}
function connect(){
  const ws=new WebSocket((location.protocol==="https:"?"wss://":"ws://")+location.host);
  ws.onmessage=e=>{const x=JSON.parse(e.data);if(x.type==="message")add(x.message)};
  ws.onclose=()=>setTimeout(connect,2000);
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
fetch("/api/me").then(r=>r.json()).then(d=>{if(d.username){me=d.username;$("login").classList.add("hidden");$("app").classList.remove("hidden");load();connect()}});
